# Bienvenida_ejem
Ejemplo en android studio
Con un fondo nine-patch y soporte para cuatro idiomas.
